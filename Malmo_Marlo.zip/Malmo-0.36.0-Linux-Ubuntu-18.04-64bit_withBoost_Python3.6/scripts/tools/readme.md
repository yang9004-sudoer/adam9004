This folder contains a (growing) selection of useful scripts, for tasks such as data processing, log checking, etc.
It's hoped that, even if a script isn't in itself particularly useful for other people, it will at least provide a step in a useful direction.
Please contribute!