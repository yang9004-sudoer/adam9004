var searchData=
[
  ['depth_5fmap',['DEPTH_MAP',['../structmalmo_1_1_timestamped_video_frame.html#a6016177a24884e003e9696bcfcf172a2a88313c1104a5fd0dc39c27becf2557d1',1,'malmo::TimestampedVideoFrame']]]
];
