var searchData=
[
  ['number_5fof_5fobservations_5fsince_5flast_5fstate',['number_of_observations_since_last_state',['../structmalmo_1_1_world_state.html#a0914aa2fb9c7062c68f90c787d7cdcb5',1,'malmo::WorldState']]],
  ['number_5fof_5frewards_5fsince_5flast_5fstate',['number_of_rewards_since_last_state',['../structmalmo_1_1_world_state.html#ae03b49ef4aee4b54fc279c2c35e85958',1,'malmo::WorldState']]],
  ['number_5fof_5fvideo_5fframes_5fsince_5flast_5fstate',['number_of_video_frames_since_last_state',['../structmalmo_1_1_world_state.html#aad86d8f9429e29788f147a0b0738b514',1,'malmo::WorldState']]]
];
