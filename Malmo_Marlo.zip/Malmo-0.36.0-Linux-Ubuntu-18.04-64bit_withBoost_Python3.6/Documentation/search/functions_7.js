var searchData=
[
  ['init_5ferror_5fcode',['init_error_code',['../classmalmo_1_1_error_code_sync.html#a8ead491f787efc28d6e0e028ae636fe1',1,'malmo::ErrorCodeSync']]],
  ['iscolourmaprequested',['isColourMapRequested',['../classmalmo_1_1_mission_spec.html#ad8cbacf5f60600bfffd66a7e6aac5c53',1,'malmo::MissionSpec']]],
  ['isdepthrequested',['isDepthRequested',['../classmalmo_1_1_mission_spec.html#a6dbddabb88a70be6edf2cfed55ff4292',1,'malmo::MissionSpec']]],
  ['isluminancerequested',['isLuminanceRequested',['../classmalmo_1_1_mission_spec.html#acdaac97519b77a6d1ed98f0be037f99f',1,'malmo::MissionSpec']]],
  ['isrecording',['isRecording',['../structmalmo_1_1_mission_record_spec.html#a5b5bbb7fb58a1722262f3f801ffa55b8',1,'malmo::MissionRecordSpec']]],
  ['isvideorequested',['isVideoRequested',['../classmalmo_1_1_mission_spec.html#af80a194eae7d906b93d5aae293e4cb0e',1,'malmo::MissionSpec']]]
];
