var searchData=
[
  ['raw_5fbmp',['RAW_BMP',['../structmalmo_1_1_timestamped_video_frame.html#a72f071afb831b7e2036255229d676515a5f4970c37a69c2cf417ef07a7feaaef8',1,'malmo::TimestampedVideoFrame']]],
  ['reverse_5fscanline',['REVERSE_SCANLINE',['../structmalmo_1_1_timestamped_video_frame.html#a72f071afb831b7e2036255229d676515a814dd49d492ea1aba42588c517e73ad3',1,'malmo::TimestampedVideoFrame']]]
];
