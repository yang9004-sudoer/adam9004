var searchData=
[
  ['pitch',['pitch',['../structmalmo_1_1_timestamped_video_frame.html#aeab0128684422b4638df723131f8519d',1,'malmo::TimestampedVideoFrame']]],
  ['pixels',['pixels',['../structmalmo_1_1_timestamped_video_frame.html#ab1b01979d9bdb998ee7830c4865f52c2',1,'malmo::TimestampedVideoFrame']]]
];
