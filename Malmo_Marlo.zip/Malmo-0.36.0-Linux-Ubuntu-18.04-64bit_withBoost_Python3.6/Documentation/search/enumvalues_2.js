var searchData=
[
  ['identity',['IDENTITY',['../structmalmo_1_1_timestamped_video_frame.html#a72f071afb831b7e2036255229d676515ab07e0b4b6969aaa6e0975c33022185f4',1,'malmo::TimestampedVideoFrame']]]
];
