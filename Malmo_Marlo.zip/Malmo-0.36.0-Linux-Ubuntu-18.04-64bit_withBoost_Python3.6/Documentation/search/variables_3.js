var searchData=
[
  ['frametype',['frametype',['../structmalmo_1_1_timestamped_video_frame.html#ae91b65922d0c3537d35a32cedd9eea7c',1,'malmo::TimestampedVideoFrame']]]
];
