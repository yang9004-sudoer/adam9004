var searchData=
[
  ['yaw',['yaw',['../structmalmo_1_1_timestamped_video_frame.html#a65986edaef6bed1171fbc8cc00258c53',1,'malmo::TimestampedVideoFrame']]],
  ['ypos',['yPos',['../structmalmo_1_1_timestamped_video_frame.html#a1210ac4aafccb9c2962153d6148a3cbb',1,'malmo::TimestampedVideoFrame']]]
];
