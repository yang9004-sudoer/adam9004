var searchData=
[
  ['frametype',['FrameType',['../structmalmo_1_1_timestamped_video_frame.html#a6016177a24884e003e9696bcfcf172a2',1,'malmo::TimestampedVideoFrame']]]
];
